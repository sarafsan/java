
package bankmanagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;


public class EmployeeCheckBalanceJf extends javax.swing.JFrame {
    Connection conn;  
    ResultSet rs;
    PreparedStatement pst=null;
    


    public EmployeeCheckBalanceJf()  {
        initComponents();
        
        this.setIconImage(new ImageIcon(getClass().getResource
        ("BankIcon3.png")).getImage());
        
        conn =javaconnect.connect();
        
        setvalue();
        
        if(rbDeposite.isEnabled())
        {
            Operation ="Deposite";
        }
    }
    
    private void setvalue()
    {        
        String getid=EmployeeHomeJf.lblAccountId.getText();       
        lblId.setText(getid);
        
        String id=lblId.getText();      
        
        try
        {
            
            String sql="select * from CustomerInfoT where CustomerId=? ";
            pst=conn.prepareStatement(sql);
            pst.setString(1, id);
            rs=pst.executeQuery();
           
            if(rs.next())
           {
               lblName.setText(rs.getString("CustomerName"));
               getBalance=rs.getDouble("AccountBalance");
               String s=java.text.NumberFormat.getCurrencyInstance().format(getBalance);
               lblTotal.setText(s);
               String time = new SimpleDateFormat("dd/MM/yyyy  HH:mm:ss").format(Calendar.getInstance().getTime());
               lblTime.setText(time);              
               
           }
            
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null,"Not connected to database :"+ex);
        }
                
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        lblName = new javax.swing.JLabel();
        lblId = new javax.swing.JLabel();
        lblTotal = new javax.swing.JLabel();
        lblTime = new javax.swing.JLabel();
        rbWithdraw = new javax.swing.JRadioButton();
        rbDeposite = new javax.swing.JRadioButton();
        bEnter = new javax.swing.JButton();
        tfAmount = new javax.swing.JTextField();
        bBack = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        lblName.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        lblId.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        lblTotal.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N

        lblTime.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblTime.setText("Time");

        buttonGroup1.add(rbWithdraw);
        rbWithdraw.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        rbWithdraw.setText("Withdraw");
        rbWithdraw.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbWithdrawActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbDeposite);
        rbDeposite.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        rbDeposite.setSelected(true);
        rbDeposite.setText("Deposit");
        rbDeposite.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbDepositeActionPerformed(evt);
            }
        });

        bEnter.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        bEnter.setText("Deposit Money");
        bEnter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEnterActionPerformed(evt);
            }
        });

        tfAmount.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        bBack.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bBack.setText("Go back");
        bBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBackActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("Account ID :");

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("Name :");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Enter Amount");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel4.setText("Balance :");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setText("Time :");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bBack, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 690, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(178, 178, 178)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(bEnter, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(192, 192, 192)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(rbDeposite, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(52, 52, 52)
                                        .addComponent(rbWithdraw, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(lblId, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(lblTime, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(lblName, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addGap(17, 17, 17)
                                        .addComponent(lblTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addGap(19, 19, 19))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblTime, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(137, 137, 137))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE)
                                    .addComponent(lblName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(36, 36, 36))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(bBack, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblId, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(4, 4, 4)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbDeposite)
                    .addComponent(rbWithdraw))
                .addGap(42, 42, 42)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(45, 45, 45)
                .addComponent(bEnter, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(102, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void rbDepositeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbDepositeActionPerformed
        Operation ="Deposite"; 
        bEnter.setText("Deposite Money");
        
    }//GEN-LAST:event_rbDepositeActionPerformed

    private void rbWithdrawActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbWithdrawActionPerformed
        Operation ="Withdraw";
        bEnter.setText("Withdraw Money");
    }//GEN-LAST:event_rbWithdrawActionPerformed

    private void bEnterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEnterActionPerformed
        
        String s=tfAmount.getText();
        
        int a=0;
                      
            try
            {
                double x=Double.parseDouble(tfAmount.getText()); 
                
            }
            catch(Exception ex)
            {
                //JOptionPane.showMessageDialog(null,"Enter Numbers");
                a=1;
            }
    
        if(s != null && !s.isEmpty())
        {
            if(a==0)
            {
          
            
        if( Operation.equals("Deposite") )
       {
          int p=JOptionPane.showConfirmDialog(null,"Do you want to Dposite "
                   + "money in this account","Deposite Money",JOptionPane.YES_NO_OPTION);
           if(p==0)
           {
           
           try
        {
            
            String sql="insert into CustomerReportT "
                    + "(CustomerId,CustomerName,Operation,Amount,"
                    + "AccountBalance2,OpTime) values(?,?,?,?,?,?) ";
            pst=conn.prepareStatement(sql);
            pst.setString(1, lblId.getText());
            pst.setString(2, lblName.getText());
            pst.setString(3, Operation);
            pst.setString(4, tfAmount.getText());
            
            
            
           
            
            
            double x=Double.parseDouble(tfAmount.getText()); 
            double total=x+getBalance;
            pst.setDouble(5, total);
            
            
                  
                           
            
           String time = new SimpleDateFormat
           ("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
            lblTime.setText(time);              
            pst.setString(6, time);
            
            pst.execute();
            
            try
            {
                String id=lblId.getText();
                String sqlu="update CustomerinfoT set "
                        + "AccountBalance='"+total+"' where"
                        + " CustomerId='"+ id+"' ";
                pst=conn.prepareStatement(sqlu);
                pst.execute();
                
                
            }
            
            catch(SQLException ex)
        {
            JOptionPane.showMessageDialog(null,"Not connected to database :"+ex);
        }
              
            String sc=java.text.NumberFormat.getCurrencyInstance().format(total);
            lblTotal.setText(sc);
            getBalance=total;
            
            JOptionPane.showMessageDialog(null,"Account updated"); 
            tfAmount.setText("");
        }
           
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null,"Not connected to database :"+ex);
        }
           }
           
       }
     
     
     
        
        if(Operation.equals("Withdraw") )
       {
           int j=JOptionPane.showConfirmDialog(null,"Do you want to Withdraw "
                   + "money from this account","Withdraw Money",JOptionPane.YES_NO_OPTION);

           if(j==0)
           {
           
           try
        {
            
            String sqlw="insert into CustomerReportT "
                    + "(CustomerId,CustomerName,Operation,Amount,"
                    + "AccountBalance2,OpTime) values(?,?,?,?,?,?) ";
            pst=conn.prepareStatement(sqlw);
            pst.setString(1, lblId.getText());
            pst.setString(2, lblName.getText());
            pst.setString(3, Operation);
            pst.setString(4, tfAmount.getText());
                      
            double xw=Double.parseDouble(tfAmount.getText());       
            double totalw=getBalance-xw;
            if(totalw>=0)
            {
            pst.setDouble(5, totalw);  
            

                    
            
           String time = new SimpleDateFormat
           ("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
            lblTime.setText(time);              
            pst.setString(6, time);
            
            pst.execute();
            
            try
            {
                String idw=lblId.getText();
                String sqluw="update CustomerinfoT set "
                        + "AccountBalance='"+totalw+"' where"
                        + " CustomerId='"+ idw+"' ";
                pst=conn.prepareStatement(sqluw);
                pst.execute();
                
                
            }
            
            catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null,"Not connected to database :"+ex);
        }
              
            String scw=java.text.NumberFormat.getCurrencyInstance().format(totalw);
            lblTotal.setText(scw);
            getBalance=totalw;
            
            JOptionPane.showMessageDialog(null,"Account updated"); 
            tfAmount.setText("");
            
            
        }
        else
          {
             JOptionPane.showMessageDialog(null,"You don't have enough money");               
          }
            
        }
           
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null,"Not connected to database :"+ex);
        }
           
       }
       }
        
            }
            else
            {
                JOptionPane.showMessageDialog(null,"Must enter Numbers");
            }
        
   }
        else
        {
            JOptionPane.showMessageDialog(null,"Must enter the amount");
        }
             
    }//GEN-LAST:event_bEnterActionPerformed

    private void bBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBackActionPerformed
        dispose();
        new EmployeeHomeJf().setVisible(true);
    }//GEN-LAST:event_bBackActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmployeeCheckBalanceJf.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmployeeCheckBalanceJf.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmployeeCheckBalanceJf.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmployeeCheckBalanceJf.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */   
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EmployeeCheckBalanceJf().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bBack;
    private javax.swing.JButton bEnter;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    public static javax.swing.JLabel lblId;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblTime;
    private javax.swing.JLabel lblTotal;
    private javax.swing.JRadioButton rbDeposite;
    private javax.swing.JRadioButton rbWithdraw;
    private javax.swing.JTextField tfAmount;
    // End of variables declaration//GEN-END:variables
    
    String Operation;
    double getBalance;
}

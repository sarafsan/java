
package bankmanagement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


public class javaconnect {
    Connection conn;
    PreparedStatement pst;
    
    public static Connection  connect()
    {
        try 
        {
            String driver ="sun.jdbc.odbc.JdbcOdbcDriver";
            Class.forName(driver);
            String db ="jdbc:odbc:BankDb";
            Connection conn = DriverManager.getConnection(db);
            //System.out.println("Connected");
            return conn;
                       
        }
        catch(Exception ex) 
        {
            //System.out.println("Not Connected Error:"+ex);
            
            return null;
                       
        }
    }
    
}

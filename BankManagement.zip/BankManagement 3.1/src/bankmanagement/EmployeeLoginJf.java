
package bankmanagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;


public class EmployeeLoginJf extends javax.swing.JFrame {
       Connection conn;  
       ResultSet rs;
       PreparedStatement pst=null;

    public EmployeeLoginJf() {
        initComponents();
        conn =javaconnect.connect();
        
        this.setIconImage(new ImageIcon(getClass().getResource
        ("BankIcon3.png")).getImage());
        
        if(rbCustomer.isEnabled())
        {
            emp=0;
        }
  
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        TfUsername = new javax.swing.JTextField();
        TfPassword = new javax.swing.JPasswordField();
        rbCustomer = new javax.swing.JRadioButton();
        rbEmployee = new javax.swing.JRadioButton();
        lblLogin = new javax.swing.JLabel();
        lblSignUp = new javax.swing.JLabel();
        lblBack = new javax.swing.JLabel();
        Bg = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TfUsername.setBackground(new java.awt.Color(51, 51, 51));
        TfUsername.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        TfUsername.setForeground(new java.awt.Color(204, 204, 204));
        TfUsername.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        TfUsername.setBorder(null);
        TfUsername.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(TfUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 260, 310, 40));

        TfPassword.setBackground(new java.awt.Color(51, 51, 51));
        TfPassword.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        TfPassword.setForeground(new java.awt.Color(204, 204, 204));
        TfPassword.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        TfPassword.setBorder(null);
        getContentPane().add(TfPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 320, 310, 40));

        buttonGroup1.add(rbCustomer);
        rbCustomer.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        rbCustomer.setSelected(true);
        rbCustomer.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rbCustomer.setContentAreaFilled(false);
        rbCustomer.setMaximumSize(new java.awt.Dimension(31, 31));
        rbCustomer.setMinimumSize(new java.awt.Dimension(30, 30));
        rbCustomer.setPreferredSize(new java.awt.Dimension(30, 30));
        rbCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbCustomerActionPerformed(evt);
            }
        });
        getContentPane().add(rbCustomer, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 390, 20, 20));

        buttonGroup1.add(rbEmployee);
        rbEmployee.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        rbEmployee.setContentAreaFilled(false);
        rbEmployee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbEmployeeActionPerformed(evt);
            }
        });
        getContentPane().add(rbEmployee, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 390, -1, -1));

        lblLogin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblLoginMouseClicked(evt);
            }
        });
        getContentPane().add(lblLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 270, 80, 70));

        lblSignUp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblSignUp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblSignUpMouseClicked(evt);
            }
        });
        getContentPane().add(lblSignUp, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 30, 170, 60));

        lblBack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblBackMouseClicked(evt);
            }
        });
        getContentPane().add(lblBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 20, 170, 70));

        Bg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bankmanagement/Login.png"))); // NOI18N
        Bg.setAlignmentY(0.0F);
        getContentPane().add(Bg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 600));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void rbCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbCustomerActionPerformed
       emp=0;
    }//GEN-LAST:event_rbCustomerActionPerformed

    private void rbEmployeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbEmployeeActionPerformed
        emp=1;
    }//GEN-LAST:event_rbEmployeeActionPerformed

    private void lblLoginMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLoginMouseClicked
        
        if(emp==1)
        {
        String sql="select * from EmployeeInfoT where UserName=? and Password=? ";
        try
        {
            pst=conn.prepareStatement(sql);
            pst.setString(1,TfUsername.getText());
            pst.setString(2,TfPassword.getText());

            rs=pst.executeQuery();
            if(rs.next())
            {
                //JOptionPane.showMessageDialog(null,"Acces granted");
                dispose();
                new EmployeeHomeJf().setVisible(true);

            }
            else
            {
                JOptionPane.showMessageDialog(null,"Invalid User name and Password");
            }
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null,"Not connected to database :"+ex);

        }
        }
        
        if(emp==0)
        {
            String sql="select * from CustomerInfoT where UserName=? and Password=? ";
        try
        {
            pst=conn.prepareStatement(sql);
            pst.setString(1,TfUsername.getText());
            pst.setString(2,TfPassword.getText());

            rs=pst.executeQuery();
            if(rs.next())
            {
                //JOptionPane.showMessageDialog(null,"Acces granted");
                dispose();
                new CustomerHomeJf().setVisible(true);

            }
            else
            {
                JOptionPane.showMessageDialog(null,"Invalid User name and Password");
            }
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null,"Not connected to database :"+ex);

        }
           
            
        }
        
    }//GEN-LAST:event_lblLoginMouseClicked

    private void lblSignUpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblSignUpMouseClicked
        
        dispose();
        new SignupJf().setVisible(true);
    }//GEN-LAST:event_lblSignUpMouseClicked

    private void lblBackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBackMouseClicked
        
        dispose();
        new HomeJf().setVisible(true);
        
    }//GEN-LAST:event_lblBackMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmployeeLoginJf.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmployeeLoginJf.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmployeeLoginJf.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmployeeLoginJf.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EmployeeLoginJf().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Bg;
    public static javax.swing.JPasswordField TfPassword;
    public static javax.swing.JTextField TfUsername;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel lblBack;
    private javax.swing.JLabel lblLogin;
    private javax.swing.JLabel lblSignUp;
    private javax.swing.JRadioButton rbCustomer;
    private javax.swing.JRadioButton rbEmployee;
    // End of variables declaration//GEN-END:variables
    int emp;
    
}
